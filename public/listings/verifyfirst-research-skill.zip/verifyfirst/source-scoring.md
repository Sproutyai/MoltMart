# Source Credibility Scoring Rubric

## Grade Definitions

### Grade A — High Credibility (Score: 3 points)

Primary and authoritative sources with rigorous editorial or peer-review processes.

| Source Type | Examples |
|---|---|
| Peer-reviewed journals | Nature, Science, The Lancet, JAMA, IEEE, ACM |
| Government sources | CDC, FDA, BLS, Census Bureau, NIH, NIST, WHO |
| Academic institutions | .edu domains with named researchers, university press releases with linked papers |
| Official documentation | RFCs, W3C specs, language/framework official docs |
| Company filings | SEC filings (10-K, 10-Q), annual reports, IR pages |
| Primary data | Original datasets, raw survey results from credible orgs |
| Standards bodies | ISO, ANSI, OWASP (for security) |

**Grade A requires:** Named authors or institutional backing, editorial/peer review, citations or methodology disclosed.

---

### Grade B — Moderate Credibility (Score: 2 points)

Established secondary sources with editorial oversight but not primary research.

| Source Type | Examples |
|---|---|
| Major news outlets | Reuters, AP, NYT, Washington Post, BBC, The Guardian |
| Wikipedia | Only when article has adequate citations (check the footnotes) |
| Established tech/industry press | Ars Technica, The Verge, Wired, TechCrunch (news, not opinion) |
| Industry reports | Gartner, Forrester, McKinsey (note: potential conflicts — see below) |
| Curated reference sites | MDN Web Docs, Stack Overflow (high-vote answers with sources) |
| Books by credible authors | Published by reputable houses, author has relevant credentials |

**Grade B requires:** Editorial process exists, corrections policy, author/org has track record.

---

### Grade C — Low Credibility (Score: 1 point)

Sources with minimal editorial oversight or potential bias. Use only when nothing better is available.

| Source Type | Examples |
|---|---|
| Personal blogs | Medium posts, Substack, personal websites |
| Forums and Q&A | Reddit, Quora, Hacker News comments |
| Social media | Twitter/X, LinkedIn posts, YouTube descriptions |
| Company marketing | Product pages, landing pages, marketing blogs |
| Unattributed content | Articles without named authors or editorial backing |
| Press releases | Company-issued PRs without third-party validation |
| Outdated sources | Any source older than 2 years for fast-moving topics |

**Grade C gets:** Used only as supporting evidence, never as sole source for a claim.

---

## Scoring Modifiers

### Recency Penalty

For topics where currency matters (tech, science, markets, politics, prices):

| Source Age | Penalty |
|---|---|
| < 6 months | No penalty |
| 6–12 months | -0.5 points (A → effective A-, B → effective B-) |
| 1–2 years | -1 point (A → effective B, B → effective C) |
| 2+ years | Grade C maximum, regardless of original source quality |

**Recency does NOT apply to:** Historical facts, foundational science, mathematical proofs, established standards, biographical data about deceased persons.

### Conflict of Interest (COI) Rules

Apply a **-1 point penalty** when the source has a financial or reputational stake in the claim:

| Scenario | Example | Impact |
|---|---|---|
| Company claims about own products | "AWS whitepaper says AWS is 99.99% reliable" | A → B at best |
| Vendor-sponsored research | "Study funded by Coca-Cola finds sugar isn't harmful" | A → B, flag COI |
| Analyst reports with client relationships | "Gartner Magic Quadrant (vendor-paid placement)" | B → C, note COI |
| Competitor claims about rivals | "Google blog post about why Chrome is faster than Firefox" | Treat as C |

**Always disclose COI** in the sources table with a note: `[COI: funded by X]` or `[COI: self-reporting]`.

---

## Special Rules

### The Wikipedia Rule

Wikipedia is Grade B **with conditions:**
1. The article must have citations (check the reference count)
2. Check the article's talk page for disputes — if flagged, downgrade to C
3. **Always follow Wikipedia's citations to primary sources** and cite those instead when possible
4. Wikipedia is a map, not the territory. Use it to find sources, not as the source.

### The Stack Overflow Rule

Stack Overflow answers are Grade C by default, **upgraded to B** when:
- Answer has 50+ upvotes
- Answer includes links to official documentation
- Answer is by a recognized contributor (library maintainer, core team member)

### The Preprint Rule

Preprints (arXiv, medRxiv, bioRxiv, SSRN) are Grade B, **not A:**
- They have not been peer-reviewed
- Always note "preprint, not peer-reviewed" in citations
- If a published version exists, cite that instead

### The News Wire Rule

Wire services (AP, Reuters, AFP) get a **+0.5 bonus** over other news because:
- They have the strictest fact-checking processes in journalism
- They are the source other outlets cite
- They rarely publish opinion as news

---

## Minimum Source Requirements

| Claim Status | Minimum Sources | Minimum Grade |
|---|---|---|
| ✅ Verified | 2+ independent sources | At least one A or B |
| ⚠️ Partial | 1 source | Any grade (noted) |
| ❓ Disputed | 2+ sources disagreeing | Note grades of each side |
| ❌ Unverified | 0 qualifying sources | — |

### What Counts as "Independent"?

Two sources are independent if:
- They are from **different organizations**
- One is not simply **citing the other**
- They don't share the **same primary source** (if two news articles both cite one study, that's 1 source, not 2)

---

## Quick Reference: Scoring a Source

```
Step 1: Identify source type → Assign base grade (A/B/C)
Step 2: Check recency       → Apply penalty if applicable
Step 3: Check COI            → Apply penalty if applicable
Step 4: Check special rules  → Wikipedia, SO, preprint, wire
Step 5: Final effective grade → Use for verification decisions
```

### Example Scoring

| Source | Base | Recency | COI | Special | Final |
|---|---|---|---|---|---|
| CDC.gov page (2024) | A (3) | 0 | 0 | — | A (3) |
| NYT article (2023) | B (2) | 0 | 0 | — | B (2) |
| AWS blog about AWS (2024) | B (2) | 0 | -1 COI | — | C (1) |
| Wikipedia (well-cited) | B (2) | 0 | 0 | Follow citations | B (2) |
| Medium blog (2021) | C (1) | -1 | 0 | — | C (0) ⚠️ |
| arXiv preprint (2024) | — | 0 | 0 | Preprint rule | B (2) |
| Reuters wire (2024) | B (2) | 0 | 0 | +0.5 wire | B+ (2.5) |
