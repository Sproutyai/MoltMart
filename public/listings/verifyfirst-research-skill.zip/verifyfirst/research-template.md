# Research Output Template

Use this template for comprehensive research responses. For quick factual answers, use the abbreviated version at the bottom.

---

## Full Research Template

```markdown
# [Research Topic]

**Confidence Level:** [🟢 High | 🟡 Medium | 🔴 Low]
**Sources consulted:** [N] | **Searches used:** [N/8]
**Date of research:** [YYYY-MM-DD]

---

## TL;DR

[2-3 sentence summary of findings. Lead with the most important verified fact. Flag any major caveats upfront.]

---

## Findings

### [Finding 1 Heading]

[Detailed paragraph with inline citations using [n] notation. Every factual claim must have a citation.]

According to [source description] [1], [verified claim]. This is further supported by [second source] [2], which reports [corroborating detail].

> ⚠️ **Caveat:** [Any partially verified elements get explicit callouts like this.]

### [Finding 2 Heading]

[Continue with additional findings, each with inline citations.]

### [Finding N Heading]

[As many sections as needed.]

---

## Verification Log

| # | Claim | Status | Sources | Notes |
|---|-------|--------|---------|-------|
| 1 | [Exact claim text] | ✅ Verified | [1], [2] | [Brief note on verification] |
| 2 | [Exact claim text] | ⚠️ Partial | [3] | [What's uncertain and why] |
| 3 | [Exact claim text] | ❌ Unverified | — | [Why it was dropped] |
| 4 | [Exact claim text] | ❓ Disputed | [4], [5] | [Nature of the disagreement] |

---

## Sources

| # | Source | Type | Grade | Date | URL |
|---|--------|------|-------|------|-----|
| [1] | [Publication/Author — Title] | [Primary/Secondary] | [A/B/C] | [YYYY-MM-DD] | [URL] |
| [2] | [Publication/Author — Title] | [Primary/Secondary] | [A/B/C] | [YYYY-MM-DD] | [URL] |
| [3] | [Publication/Author — Title] | [Primary/Secondary] | [A/B/C] | [YYYY-MM-DD] | [URL] |

**Source grading:**
- **A** = Peer-reviewed, .gov/.edu, official documentation, primary data
- **B** = Major news outlets, Wikipedia (cited), established industry publications
- **C** = Blogs, forums, social media, opinion pieces

---

## ❓ What I Don't Know

This section is **mandatory**. Intellectual honesty requires acknowledging gaps.

- [Thing you couldn't verify within the search budget]
- [Adjacent question that came up but wasn't in scope]
- [Data point that would strengthen the analysis if available]
- [Potential bias in available sources — e.g., "Most sources were from US-based outlets"]

---

## Methodology Notes

- **Searches used:** [N] of 8 budget
- **Search queries:** [List the actual queries used, for reproducibility]
- **Verification approach:** [Any notable choices — e.g., "Prioritized primary sources over news coverage"]
- **Known limitations:** [E.g., "Paywalled sources could not be accessed"]
```

---

## Abbreviated Template (Quick Factual Answers)

For short answers where the full template would be overkill:

```markdown
[Direct answer to the question with inline citations.]

**Confidence:** [🟢/🟡/🔴] | **Sources:** [N]

[1] [Source name — URL — Grade]
[2] [Source name — URL — Grade]

> ℹ️ **Unverified:** [Anything you couldn't confirm, if applicable]
```

---

## Usage Guidelines

1. **Always use the full template** for: multi-faceted research questions, claims with significant consequences (health, legal, financial), anything the user will rely on for decision-making.

2. **Use the abbreviated template** for: single-fact lookups, confirmations of straightforward claims, follow-up questions within an already-researched topic.

3. **The "What I Don't Know" section is never empty.** There is always something you don't know. If you think there isn't, you haven't thought hard enough.

4. **Verification log includes ALL claims** — even the ones that were verified successfully. This lets the user audit your work.

5. **Sources table includes actual URLs** whenever possible. A source without a URL is harder for the user to verify independently.

6. **Date everything.** Research decays. A perfectly verified answer today may be wrong in 6 months.
