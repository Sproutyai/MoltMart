# VerifyFirst — Configuration Guide

Customize VerifyFirst's behavior by setting these options in your system prompt or as runtime instructions.

---

## Confidence Modes

Set the verification strictness level. Default: **Balanced**.

### Strict Mode
```
verifyfirst_mode: strict
```
- **2-source minimum** for ALL claims (no exceptions)
- Only Grade A and B sources accepted
- All ❌ Unverified claims explicitly listed in a "Dropped Claims" section
- 40% of search budget reserved for skeptical/debunking queries
- **Best for:** Medical/health research, legal facts, financial data, academic work

### Balanced Mode (Default)
```
verifyfirst_mode: balanced
```
- 2-source minimum for key claims; single Grade A source accepted for minor facts
- All source grades accepted (Grade C flagged)
- Unverified claims silently dropped unless user asks
- Even split between direct, skeptical, and authoritative queries
- **Best for:** General research, journalism, business analysis

### Permissive Mode
```
verifyfirst_mode: permissive
```
- Single source accepted for ✅ Verified status
- Grade C sources accepted without flag for non-critical claims
- Unverified claims kept with explicit ❌ marker (user decides)
- Prioritize speed: favor direct queries, skip skeptical unless suspicious
- **Best for:** Brainstorming, quick lookups, low-stakes research, exploration

---

## Search Budget

Control cost by limiting searches per response.

```
verifyfirst_max_searches: 8        # Default
verifyfirst_max_searches: 4        # Budget mode
verifyfirst_max_searches: 12       # Deep research mode
verifyfirst_max_searches_per_claim: 3  # Default cap per individual claim
```

### Cost Estimates

Approximate costs per response (varies by search API):

| Budget | Searches | Est. Cost (web search API) | Best For |
|---|---|---|---|
| Minimal | 2-3 | ~$0.01-0.02 | Single fact checks |
| Standard | 6-8 | ~$0.03-0.06 | Normal research |
| Deep | 10-12 | ~$0.06-0.10 | Comprehensive research |

> **Note:** Costs depend on your search API. Brave Search API: ~$0.005/query. Google Custom Search: ~$0.005/query. Perplexity: ~$0.005/query. SerpAPI: ~$0.01/query.

---

## Domain Controls

### Blocklist — Never use these as sources
```
verifyfirst_blocklist:
  - contentfarm.example.com
  - known-misinfo-site.com
```

### Allowlist — Prioritize these domains
```
verifyfirst_allowlist:
  - nature.com
  - science.org
  - cdc.gov
  - arxiv.org
```

### Domain Overrides — Force a grade for specific domains
```
verifyfirst_domain_grades:
  arxiv.org: B          # Preprints are B, not A
  company-blog.com: C   # Vendor content
  reuters.com: A        # Upgrade wire service
```

---

## Output Options

### Silent Mode
```
verifyfirst_silent: true
```
When enabled:
- Verification happens internally but the output looks like a normal response
- No verification log, no sources table, no "What I Don't Know"
- Inline citations still appear as `[n]` with a collapsed sources list at the end
- **Use when:** You want verified output but don't want the full research format

### Verbose Mode
```
verifyfirst_verbose: true
```
When enabled:
- Show the actual search queries used
- Show which claims were extracted in Phase 1
- Show the source scoring calculation
- **Use when:** Debugging verification behavior, auditing the process

### Citation Style
```
verifyfirst_citation_style: numeric    # [1], [2], [3] — Default
verifyfirst_citation_style: inline     # (Author, Year)
verifyfirst_citation_style: footnote   # Superscript with footnotes
```

---

## Claim Filtering

Control which claims trigger verification:

```
# Skip verification for these claim types
verifyfirst_skip:
  - definitions          # "Python is a programming language"
  - math                 # "2 + 2 = 4"
  - common_knowledge     # "The sun rises in the east"

# Always verify these (even in permissive mode)
verifyfirst_always_verify:
  - health               # Any medical/health claim
  - financial            # Revenue, market cap, prices
  - legal                # Laws, regulations, court decisions
```

---

## Integration Examples

### System Prompt (Claude/GPT)
```
You are a research assistant. Follow the VerifyFirst protocol from skill.md for all factual responses.

Configuration:
- verifyfirst_mode: strict
- verifyfirst_max_searches: 8
- verifyfirst_citation_style: numeric
- verifyfirst_silent: false
```

### With OpenClaw / Custom Agent
```yaml
skills:
  - path: verifyfirst/skill.md
    config:
      mode: balanced
      max_searches: 8
      silent: false
      blocklist:
        - contentfarm.com
```

### With Cursor / Windsurf / IDE Agents
Add to your `.cursorrules` or equivalent:
```
When answering factual questions, follow the VerifyFirst protocol:
1. Extract claims from your draft
2. Search to verify (max 8 searches)
3. Score sources (A/B/C grades)
4. Only include verified claims in final response
5. Always cite sources with [n] notation

See @verifyfirst/skill.md for the complete protocol.
```

---

## Troubleshooting

| Issue | Solution |
|---|---|
| Too many searches, slow responses | Lower `max_searches` to 4, use `permissive` mode |
| Output too verbose | Enable `silent` mode |
| Dropping too many claims | Switch from `strict` to `balanced` mode |
| Citing low-quality sources | Add problematic domains to blocklist |
| Missing important nuance | Increase `max_searches` to 12, use `strict` mode |
| Agent ignoring the protocol | Move skill.md to system prompt (higher priority than file attachment) |
